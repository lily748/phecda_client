package com.cocos.service;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.LoggingBehavior;
import com.facebook.appevents.AppEventsConstants;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Collection;
import com.cocos.lib.CocosHelper;
import com.cocos.lib.CocosJavascriptJavaBridge;
public class FacebookSdk {
    private static String TAG = "FacebookSdk";
    private static FacebookSdk mInstance = null;
    private Activity mActivity = null;
    private CallbackManager mCallbackManager = null;
    private ShareDialog mShareDialog = null;

    public static FacebookSdk getInstance() {
        if (null == mInstance) {
            mInstance = new FacebookSdk();
        }
        return mInstance;
    }

    /**
     *  监听 onActivityResult
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(data!=null)
        Log.i(TAG, "onActivityResult data = " + data.toString());
        if (mCallbackManager != null) {
            mCallbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    /**
     *  初始化
     */
    public void initSdk(Activity activity) {
        Log.i(TAG, "initSdk");
        mActivity = activity;
        mCallbackManager = CallbackManager.Factory.create();
        initLogin();
        initShare();
    }

    /**
     *  初始化登录
     */
    private void initLogin() {
        Log.i(TAG, "initLogin");
        LoginManager.getInstance().registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                String token = loginResult.getAccessToken().getToken();
                Log.e(TAG, "login onSuccess loginResult = " + token);
                getUserInfo(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                Log.e(TAG, "login onCancel");
                sendToCocos("FacebookLoginRet",String.format("{\"cancel\":\"\"}"));
            }

            @Override
            public void onError(FacebookException error) {
                Log.e(TAG, "login onError error = " + error.toString());
                sendToCocos("FacebookLoginRet",String.format("{\"error\":\"%s\"}",error.toString()));
            }
        });
    }

    private void getUserInfo(AccessToken token){
        if(token == null){
            return ;
        }
        GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {
                if(object == null){
                    Log.d(TAG, "无法获取fb用户基本信息");
                    sendToCocos("FacebookLoginRet",String.format("{\"error\":\"%s\"}",response.getError()));
                    return;
                }
                sendToCocos("FacebookLoginRet",object.toString());
            }
        });
        Bundle param = new Bundle();
        param.putString("fields", "id,name,gender,email,picture");
        request.setParameters(param);
        request.executeAsync();
    }

    /**
     *  登录
     */
    public void login() {
        Log.i(TAG, "login");
        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        boolean isLoggedIn = accessToken != null && !accessToken.isExpired();
        if (isLoggedIn){
            getUserInfo(accessToken);
            return;
        }

        Collection<String> permissions = Arrays.asList("gaming_user_picture,email");
        LoginManager.getInstance().logInWithReadPermissions(mActivity, permissions);
    }

    /**
     *  登出
     */
    public void logout() {
        Log.i(TAG, "logout");
        LoginManager.getInstance().logOut();
    }

    /**
     *  初始化分享
     */
    private void initShare() {
        Log.i(TAG, "initShare");
        mShareDialog = new ShareDialog(mActivity);
        mShareDialog.registerCallback(mCallbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {
                Log.e(TAG, "share onSuccess result = " + result.toString());
                sendToCocos("FacebookShareRet",String.format("{\"success\":\"%s\"}",result.toString()));
            }

            @Override
            public void onCancel() {
                Log.e(TAG, "share onCancel");
                //通知js
                sendToCocos("FacebookShareRet",String.format("{\"cancel\":\"%s\"}",""));
            }

            @Override
            public void onError(FacebookException error) {
                Log.e(TAG, "share onError error = " + error.toString());
                sendToCocos("FacebookShareRet",String.format("{\"error\":\"%s\"}",error.toString()));
            }
        });
    }

    /**
     *  分享
     */
    public void share(String shareInfo) {
        Log.i(TAG, "share shareInfo = " + shareInfo);
        try {
            JSONObject json = new JSONObject(shareInfo);
            int shareType = json.getInt("shareType");
            String shareUrl = json.getString("shareUrl");
            String imgPath = json.getString("imgPath");

            if (shareType == 0) {
                //链接
                if (ShareDialog.canShow(ShareLinkContent.class)) {
                    ShareLinkContent content = new ShareLinkContent.Builder()
                            .setContentUrl(Uri.parse(shareUrl))
                            .build();
                    mShareDialog.show(content);
                }
            } else if (shareType == 1) {
                //图片
                if (ShareDialog.canShow(SharePhotoContent.class)) {
                    Bitmap img = BitmapFactory.decodeFile(imgPath);
                    SharePhoto photo = new SharePhoto.Builder()
                            .setBitmap(img)
                            .build();
                    SharePhotoContent content = new SharePhotoContent.Builder()
                            .addPhoto(photo)
                            .build();
                    mShareDialog.show(content);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void reportAppEvent(String content){
//        com.facebook.FacebookSdk.setIsDebugEnabled(true);
//        com.facebook.FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
        try{
            AppEventsLogger.activateApp(mActivity.getApplication());
            Log.e(TAG, "Facebook reportData: "+content);
            JSONObject obj = new JSONObject(content);
            String eventName = obj.getString("event");
            Bundle params = new Bundle();
            AppEventsLogger logger = AppEventsLogger.newLogger(mActivity);
            if (eventName.contains("fb_mobile_purchase") ){
                JSONObject paramsObj = obj.getJSONObject("params");
                Log.e("FaceBook", "reportData222: "+eventName);
                String orderid = paramsObj.getString("orderId");
                double price = paramsObj.getInt("price");
                int quantity = paramsObj.getInt("quantity");
                String currency = paramsObj.getString("currency");
                params.putString(AppEventsConstants.EVENT_PARAM_CURRENCY, currency);
                params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, "product");
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", orderid);
                jsonObject.put("quantity", quantity);
                params.putString(AppEventsConstants.EVENT_PARAM_CONTENT, jsonObject.toString());
                logger.logEvent(eventName,price,params);
            }else{
                params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, "m_"+eventName);
                if (obj.has("params")){
                    params.putString(AppEventsConstants.EVENT_PARAM_CONTENT, obj.getString("params"));
                }
                logger.logEvent(eventName,params);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void sendToCocos(String function,String args){
        CocosHelper.runOnGameThread(new Runnable() {
            @Override
            public void run() {
                final String eval = String.format("window.GameSDKInterface.%s(`%s`)",function,args);
                Log.d("sendToCocos ",eval);
                CocosJavascriptJavaBridge.evalString(eval);
            }
        });
    }
}
