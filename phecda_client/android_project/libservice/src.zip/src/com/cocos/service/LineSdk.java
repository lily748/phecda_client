package com.cocos.service;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.cocos.lib.CocosHelper;
import com.cocos.lib.CocosJavascriptJavaBridge;
import com.linecorp.linesdk.Scope;
import com.linecorp.linesdk.auth.LineAuthenticationParams;
import com.linecorp.linesdk.auth.LineLoginApi;
import com.linecorp.linesdk.auth.LineLoginResult;

import java.util.Arrays;

public class LineSdk {
    private static String TAG = "LineSdk";
    private static LineSdk mInstance = null;
    private Activity mActivity = null;
    private String mChannel;
    private static final int REQUEST_CODE = 1;

    public static LineSdk getInstance() {
        if (null == mInstance) {
            mInstance = new LineSdk();
        }
        return mInstance;
    }

    public void initSdk(Activity activity,String channel) {
        Log.i(TAG, "initSdk");
        mActivity = activity;
        mChannel = channel;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode != REQUEST_CODE)
            return;
        LineLoginResult result = LineLoginApi.getLoginResultFromIntent(data);
        Log.d(TAG, "lineSdk onActivityResult: "+ result.toString());
        switch (result.getResponseCode()) {
            case SUCCESS:
                String id = result.getLineProfile().getUserId();
                //昵称：Zhang San
                String name = result.getLineProfile().getDisplayName();
                //头像
                String picture = result.getLineProfile().getPictureUrl().toString();
                String authInfo = String.format("{\"id\":\"%s\",\"name\":\"%s\",\"picture\":\"%s\"}",id, name, picture);
                sendToCocos("LineLoginRet",authInfo);
                break;
            case CANCEL:
                // Login canceled by user
                Log.e(TAG, "LINE Login Canceled by user."+result);
                sendToCocos("LineLoginRet",String.format("{\"cancel\":\"\"}"));
                break;

            default:
                // Login canceled due to other error
                Log.e(TAG, result.getErrorData().toString());
                sendToCocos("LineLoginRet",String.format("{\"error\":\"\"}"));
        }
    }

    public void login() {
        try{
            Log.i(TAG, "login");
            // App-to-app login
            Intent loginIntent = LineLoginApi.getLoginIntent(
                    mActivity.getApplicationContext(),
                    mChannel,
                    new LineAuthenticationParams.Builder()
                            .scopes(Arrays.asList(Scope.PROFILE))
                            // .nonce("<a randomly-generated string>") // nonce can be used to improve security
                            .build());
            mActivity.startActivityForResult(loginIntent, REQUEST_CODE);
        }
        catch(Exception e) {
            Log.e("ERROR", e.toString());
        }
    }

    public void sendToCocos(String function,String args){
        CocosHelper.runOnGameThread(new Runnable() {
            @Override
            public void run() {
                final String eval = String.format("window.GameSDKInterface.%s(`%s`)",function,args);
                Log.d("sendToCocos ",eval);
                CocosJavascriptJavaBridge.evalString(eval);
            }
        });
    }
}
